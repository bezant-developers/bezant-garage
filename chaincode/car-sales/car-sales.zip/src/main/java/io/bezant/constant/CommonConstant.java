package io.bezant.constant;

public class CommonConstant {
    public static final String PREFIX_CAR_COMPOSITE_KEY = "BRAND_ID";
}