package io.bezant.constant;

public class CommonConstant {
    public static final String PREFIX_COMPOSITE_KEY_USER = "User";
}
